﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Layout.Models
{
    public class UpdateQuantityInput
    {
        public bool Plus { get; set; }
        public string ProductId { get; set; }
    }
}
